<!DOCTYPE html>
<html>

<head>
    <title>Count from 5 to 15</title>
</head>

<body>
    <h1>Count from 5 to 15:</h1>
    <ul>
        <?php
        for ($i = 5; $i <= 15; $i++) {
            echo "<li>$i</li>";
        }
        ?>
    </ul>
</body>

</html>